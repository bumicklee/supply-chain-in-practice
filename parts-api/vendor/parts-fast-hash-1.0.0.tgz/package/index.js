exports.hash = value => require("./build/binding.js").hash(value);
